package common.controller;

import org.junit.Test;

public class SQSControllerTest {

	SQSController mSqsController = SQSController.getInstance();

	@Test
	public void test() {
	}

}
